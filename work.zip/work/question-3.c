#include<stdio.h>
#include<conio.h>
void main(){
	int first_angle=65;
	printf("first-angle:- %d\n",first_angle);
	int Second_angle=45;
	printf("Second-angle:- %d\n",Second_angle);
	int third_angle;
	 
	third_angle=first_angle+Second_angle-180;
	printf("third-angle is:- %d\n",third_angle); 
	 
	
	
	
	
	
	
	
	
	
	getch();
}
