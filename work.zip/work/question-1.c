#include<stdio.h>
#include<conio.h>
void main()
{
	int c;
	float f;
	printf("Enter a temperature  in Celsius:- ");
	scanf("%d",&c);
	 f=(c*9/5)+32;	
	 printf("The temperature in Fahrenheit:- %f",f);
	
	
	
	
	
	
	
	
	
	
	getch();
}
